// Tiny inline Lucide-style icon set
const ICON_PATHS = {
  heart: <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>,
  heartFill: <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" fill="currentColor"/>,
  camera: <g><path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"/><circle cx="12" cy="13" r="4"/></g>,
  send: <g><path d="m22 2-7 20-4-9-9-4 20-7z"/><path d="M22 2 11 13"/></g>,
  check: <polyline points="20 6 9 17 4 12"/>,
  sparkles: <g><path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z"/><path d="M19 17l.95 2.55L22 20.5l-2.05.95L19 24l-.95-2.55L16 20.5l2.05-.95z"/><path d="M5 3l.66 1.77L7.5 5.5l-1.84.73L5 8l-.66-1.77L2.5 5.5l1.84-.73z"/></g>,
  refresh: <g><path d="M21 12a9 9 0 0 1-15.5 6.4L1 14"/><path d="M3 12a9 9 0 0 1 15.5-6.4L23 10"/><polyline points="17 4 23 10 17 16"/><polyline points="7 20 1 14 7 8"/></g>,
  paw: <g><circle cx="7" cy="9" r="2"/><circle cx="17" cy="9" r="2"/><circle cx="5" cy="14" r="1.8"/><circle cx="19" cy="14" r="1.8"/><path d="M8 19a4 4 0 0 1 8 0c0 1.5-1 2-2 2h-4c-1 0-2-.5-2-2z"/></g>,
  gallery: <g><rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.5-3.5-7 7"/></g>,
  feed: <g><rect x="3" y="3" width="18" height="18" rx="3"/><path d="M7 8h10M7 12h7M7 16h4"/></g>,
  cake: <g><path d="M20 21v-8H4v8z"/><path d="M2 21h20"/><path d="M7 8a2 2 0 1 1 4 0c0 1-2 2-2 4M14 8a2 2 0 1 1 4 0c0 1-2 2-2 4"/></g>,
  cal: <g><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/></g>,
  gift: <g><rect x="3" y="8" width="18" height="13" rx="2"/><path d="M12 8v13M3 12h18M7.5 8a2.5 2.5 0 1 1 0-5C13 3 12 8 12 8s-1-5 4.5-5a2.5 2.5 0 1 1 0 5"/></g>,
  bolt: <polygon points="13 2 3 14 12 14 11 22 21 10 12 10"/>,
  smile: <g><circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/></g>,
  chev: <polyline points="9 18 15 12 9 6"/>,
  bell: <g><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10 21a2 2 0 0 0 4 0"/></g>,
  plus: <g><path d="M12 5v14M5 12h14"/></g>,
  flame: <path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"/>,
  star: <polygon points="12 2 15 9 22 9 17 14 19 22 12 18 5 22 7 14 2 9 9 9"/>,
  pin: <g><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0z"/><circle cx="12" cy="10" r="3"/></g>,
  dice: <g><rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8" cy="8" r="1.2"/><circle cx="16" cy="16" r="1.2"/><circle cx="16" cy="8" r="1.2"/><circle cx="8" cy="16" r="1.2"/><circle cx="12" cy="12" r="1.2"/></g>,
  arrow: <g><path d="M5 12h14"/><polyline points="12 5 19 12 12 19"/></g>,
  bubble: <g><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></g>,
};

function Icon({ name, size = 20, color = 'currentColor', strokeWidth = 2, fill = 'none', style = {} }) {
  const node = ICON_PATHS[name];
  if (!node) return null;
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={fill}
      stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round"
      style={{ flexShrink: 0, ...style }}>
      {node}
    </svg>
  );
}

window.Icon = Icon;
