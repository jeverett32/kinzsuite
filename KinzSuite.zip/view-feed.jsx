// ─── View 3: Today (checklist + activity) ────────────────────────────

function TodayView({ palette, names, tasks, setTasks }) {
  const toggle = (id) => setTasks(ts => ts.map(t => t.id === id ? { ...t, done: !t.done } : t));
  const completed = tasks.filter(t => t.done).length;
  const pct = Math.round((completed / tasks.length) * 100);

  return (
    <div style={{ padding: '0 0 24px' }}>
      {/* Header */}
      <div style={{ padding: '4px 18px 12px', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', gap: 10 }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontFamily: 'Caveat', fontSize: 22, color: '#fff', textShadow: `0 2px 0 ${palette.ink}` }}>Tuesday · May 13</div>
          <div className="kz-display" style={{ fontSize: 28, color: palette.ink, marginTop: 2, lineHeight: 1, textShadow: '0 2px 0 rgba(255,255,255,0.5)' }}>
            SHARED DAY
          </div>
        </div>
        <Chip palette={palette} tone="grass">{completed}/{tasks.length} done</Chip>
      </div>

      {/* Stat trio */}
      <div style={{ padding: '0 18px 14px', display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
        {[
          { k: 'STREAK',  v: '9d',  c: palette.sun,   icon: 'flame'     },
          { k: 'BOND',    v: '+14', c: palette.blush, icon: 'heartFill' },
          { k: 'PETS',    v: '8/8', c: palette.grass, icon: 'paw'       },
        ].map((s, i) => (
          <div key={i} className="kz-sticker" style={{
            '--ink': palette.ink,
            borderRadius: 18, padding: '10px 8px',
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2,
          }}>
            <div style={{
              width: 30, height: 30, borderRadius: 99,
              background: `linear-gradient(180deg, ${s.c}, ${kzShade(s.c, -15)})`,
              border: `2px solid ${palette.ink}`, color: '#fff',
              display: 'grid', placeItems: 'center',
            }}>
              <Icon name={s.icon} size={15} strokeWidth={2.4} />
            </div>
            <div className="kz-display" style={{ fontSize: 18, color: palette.ink, lineHeight: 1, marginTop: 4 }}>{s.v}</div>
            <div style={{ fontSize: 9, fontWeight: 700, color: palette.ink, opacity: 0.6, letterSpacing: 0.6 }}>{s.k}</div>
          </div>
        ))}
      </div>

      {/* CHECKLIST */}
      <div style={{ padding: '0 18px 14px' }}>
        <div className="kz-sticker" style={{ '--ink': palette.ink, borderRadius: 24, padding: 14 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12, gap: 10 }}>
            <div className="kz-display" style={{ fontSize: 16, color: palette.ink, letterSpacing: 0.4, flexShrink: 0 }}>QUESTS</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, flex: 1, justifyContent: 'flex-end' }}>
              <div style={{
                width: 80, height: 12, borderRadius: 99, overflow: 'hidden',
                background: '#fff', border: `2px solid ${palette.ink}`,
              }}>
                <div style={{
                  width: `${pct}%`, height: '100%',
                  background: `linear-gradient(90deg, ${palette.grass}, ${palette.sky})`,
                  borderRadius: 99, transition: 'width .3s',
                }} />
              </div>
              <span className="kz-display" style={{ fontSize: 14, color: palette.ink }}>{pct}%</span>
            </div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            {tasks.map((t, i) => (
              <button key={t.id} onClick={() => toggle(t.id)} style={{
                display: 'flex', alignItems: 'center', gap: 10, padding: '10px 4px',
                background: 'transparent', border: 'none', cursor: 'pointer', textAlign: 'left',
                fontFamily: 'inherit',
                borderTop: i ? `2px dashed ${palette.ink}20` : 'none',
              }}>
                <div style={{
                  width: 28, height: 28, borderRadius: 9, flexShrink: 0,
                  background: t.done ? `linear-gradient(180deg, ${palette.grass}, ${kzShade(palette.grass, -15)})` : '#fff',
                  border: `2.5px solid ${palette.ink}`,
                  boxShadow: t.done ? `0 3px 0 ${palette.ink}` : `0 2px 0 ${palette.ink}`,
                  display: 'grid', placeItems: 'center',
                  transition: 'all .15s',
                }}>
                  {t.done && <Icon name="check" size={16} color="#fff" strokeWidth={3.5} />}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{
                    fontSize: 14, fontWeight: 600, color: palette.ink,
                    textDecoration: t.done ? 'line-through' : 'none',
                    opacity: t.done ? 0.5 : 1,
                  }}>{t.label}</div>
                </div>
                <Chip palette={palette} tone={t.who === 'me' ? 'sky' : t.who === 'partner' ? 'blush' : 'grass'}>
                  {t.who === 'me' ? names.me : t.who === 'partner' ? names.partner : 'both'}
                </Chip>
                <span className="kz-display" style={{ fontSize: 12, color: palette.ink, opacity: 0.7, minWidth: 56, textAlign: 'right' }}>{t.reward}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

window.TodayView = TodayView;
