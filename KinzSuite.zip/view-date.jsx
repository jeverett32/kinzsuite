// ─── View 2: Date Night Generator ────────────────────────────────────

// Helpers
function kzPolar(cx, cy, r, deg) {
  const rad = (deg - 90) * Math.PI / 180; // 0deg = top
  return { x: cx + r * Math.cos(rad), y: cy + r * Math.sin(rad) };
}

// ─── Spinning wheel ──────────────────────────────────────────────────
function DateWheel({ palette, quests, spinning, setSpinning, onLand }) {
  const [rotation, setRotation] = React.useState(0);
  const [pressed, setPressed] = React.useState(false);
  const N = quests.length;
  const slice = 360 / N;
  const SIZE = 280;
  const cx = SIZE / 2, cy = SIZE / 2;
  const rOuter = SIZE / 2 - 4;
  const rRim   = rOuter - 10;
  const rHub   = 38;

  // Rainbow-of-slice colors, in KinzSuite-friendly hues
  const SLICE_COLORS = [
    '#E94B7B', // pink
    '#E2553A', // red-orange
    '#F0A93A', // orange
    '#F2D24B', // yellow
    '#7DBE43', // green
    '#3FB4A1', // teal
    '#3F8EE0', // blue
    '#8E6BD9', // purple
  ];
  const colorFor = (i) => SLICE_COLORS[i % SLICE_COLORS.length];

  const spin = () => {
    if (spinning) return;
    const target = Math.floor(Math.random() * N);
    const turns  = 5 + Math.floor(Math.random() * 3);
    const targetCenter = target * slice + slice / 2;
    const currentMod = ((rotation % 360) + 360) % 360;
    const desired = (360 - targetCenter) % 360;
    const delta = ((desired - currentMod) + 360) % 360 + 360 * turns;
    setSpinning(true);
    setRotation(rotation + delta);
    setTimeout(() => {
      setSpinning(false);
      onLand(target);
    }, 4300);
  };

  const STAGE_W = SIZE + 70;
  const STAGE_H = SIZE + 200;
  const CURTAIN_RED = '#B2191A';
  const CURTAIN_DEEP = '#7C0F11';
  const CURTAIN_HI = '#E74A4C';
  const YELLOW_DEEP = '#C89018';
  const YELLOW_MID = '#F2C744';
  const YELLOW_HI = '#FFE082';
  const ROPE_DARK = '#A86C18';
  const ROPE_MID = '#E0A02E';
  const ROPE_HI = '#FFD66E';
  const PLATFORM = '#3FA8E0';
  const PLATFORM_HI = '#9CD5EF';
  const PLATFORM_DEEP = '#1B69A0';

  // Red curtain fold pattern (vertical stripes)
  const redCurtainBg = `repeating-linear-gradient(90deg,
    ${CURTAIN_DEEP} 0px, ${CURTAIN_RED} 8px, ${CURTAIN_HI} 14px,
    ${CURTAIN_RED} 20px, ${CURTAIN_DEEP} 28px)`;
  // Yellow back-curtain fold pattern
  const yellowCurtainBg = `repeating-linear-gradient(90deg,
    ${YELLOW_DEEP} 0px, ${YELLOW_MID} 5px, ${YELLOW_HI} 10px,
    ${YELLOW_MID} 15px, ${YELLOW_DEEP} 20px)`;

  return (
    <div style={{ position: 'relative', width: STAGE_W, height: STAGE_H, margin: '0 auto' }}>
      {/* Stage backdrop with yellow curtain wall behind everything */}
      <div aria-hidden="true" style={{
        position: 'absolute', inset: 0,
        background: yellowCurtainBg,
        borderRadius: 22,
        border: `2.5px solid ${palette.ink}`,
        boxShadow: `0 4px 0 ${palette.ink}`,
        overflow: 'hidden',
        zIndex: 1,
      }}>
        {/* Spotlight glow behind wheel */}
        <div style={{
          position: 'absolute', top: 30, left: '50%', width: SIZE + 60, height: SIZE + 60,
          transform: 'translateX(-50%)',
          background: 'radial-gradient(circle at 50% 40%, rgba(255,255,210,0.55) 0%, rgba(255,255,210,0) 65%)',
          pointerEvents: 'none',
        }} />
        {/* Wooden floor line under everything */}
        <div style={{
          position: 'absolute', bottom: 0, left: 0, right: 0, height: 60,
          background: `linear-gradient(180deg, #8a5a2c 0%, #5a3a1c 100%)`,
          borderTop: `2px solid ${palette.ink}`,
        }} />
      </div>

      {/* Top red valance */}
      <div aria-hidden="true" style={{
        position: 'absolute', top: 0, left: 0, right: 0, height: 42,
        background: redCurtainBg,
        borderRadius: '22px 22px 0 0',
        borderBottom: `2px solid ${palette.ink}`,
        zIndex: 3,
      }} />
      <svg viewBox="0 0 200 14" preserveAspectRatio="none" style={{
        position: 'absolute', top: 42, left: 0, width: '100%', height: 14, display: 'block',
        zIndex: 3,
      }}>
        <path d="M 0 0 Q 10 14 20 0 Q 30 14 40 0 Q 50 14 60 0 Q 70 14 80 0 Q 90 14 100 0 Q 110 14 120 0 Q 130 14 140 0 Q 150 14 160 0 Q 170 14 180 0 Q 190 14 200 0 L 200 0 L 0 0 Z"
          fill={CURTAIN_RED} stroke={palette.ink} strokeWidth={1} />
      </svg>

      {/* Left red curtain — tied at middle with yellow rope */}
      <div aria-hidden="true" style={{
        position: 'absolute', top: 0, left: 0, bottom: 60, width: 72,
        background: redCurtainBg,
        borderRight: `2.5px solid ${palette.ink}`,
        borderRadius: '0 14px 0 0',
        // Tie-back pinch: full width top, narrows at 55%, full width bottom
        clipPath: 'polygon(0 0, 100% 0, 100% 48%, 55% 56%, 100% 64%, 100% 100%, 0 100%)',
        zIndex: 2,
      }} />
      {/* Left rope tieback */}
      <div aria-hidden="true" style={{
        position: 'absolute', top: '47%', left: 8, width: 86, height: 18,
        zIndex: 4,
      }}>
        {/* Rope cord */}
        <div style={{
          position: 'absolute', top: 4, left: 0, right: 16, height: 10,
          background: `linear-gradient(180deg, ${ROPE_HI} 0%, ${ROPE_MID} 50%, ${ROPE_DARK} 100%)`,
          border: `2px solid ${palette.ink}`,
          borderRadius: '4px 10px 10px 4px',
          boxShadow: `0 2px 0 ${palette.ink}`,
        }} />
        {/* Rope knot/tassel */}
        <div style={{
          position: 'absolute', top: 0, right: 0, width: 22, height: 18,
          background: `radial-gradient(circle at 35% 30%, ${ROPE_HI} 0%, ${ROPE_MID} 55%, ${ROPE_DARK} 100%)`,
          border: `2px solid ${palette.ink}`,
          borderRadius: '50%',
          boxShadow: `0 2px 0 ${palette.ink}`,
        }} />
      </div>

      {/* Right red curtain — mirror tieback */}
      <div aria-hidden="true" style={{
        position: 'absolute', top: 0, right: 0, bottom: 60, width: 72,
        background: redCurtainBg,
        borderLeft: `2.5px solid ${palette.ink}`,
        borderRadius: '14px 0 0 0',
        clipPath: 'polygon(0 0, 100% 0, 100% 100%, 0 100%, 0 64%, 45% 56%, 0 48%)',
        zIndex: 2,
      }} />
      <div aria-hidden="true" style={{
        position: 'absolute', top: '47%', right: 8, width: 86, height: 18,
        zIndex: 4,
      }}>
        <div style={{
          position: 'absolute', top: 4, right: 0, left: 16, height: 10,
          background: `linear-gradient(180deg, ${ROPE_HI} 0%, ${ROPE_MID} 50%, ${ROPE_DARK} 100%)`,
          border: `2px solid ${palette.ink}`,
          borderRadius: '10px 4px 4px 10px',
          boxShadow: `0 2px 0 ${palette.ink}`,
        }} />
        <div style={{
          position: 'absolute', top: 0, left: 0, width: 22, height: 18,
          background: `radial-gradient(circle at 65% 30%, ${ROPE_HI} 0%, ${ROPE_MID} 55%, ${ROPE_DARK} 100%)`,
          border: `2px solid ${palette.ink}`,
          borderRadius: '50%',
          boxShadow: `0 2px 0 ${palette.ink}`,
        }} />
      </div>

      {/* Pointer (red arrow at top of wheel) */}
      <div aria-hidden="true" style={{
        position: 'absolute', top: 64, left: '50%',
        transform: 'translateX(-50%)', zIndex: 6,
        width: 0, height: 0,
        borderLeft: '14px solid transparent',
        borderRight: '14px solid transparent',
        borderTop: `28px solid ${palette.ink}`,
      }} />
      <div aria-hidden="true" style={{
        position: 'absolute', top: 68, left: '50%',
        transform: 'translateX(-50%)', zIndex: 7,
        width: 0, height: 0,
        borderLeft: '10px solid transparent',
        borderRight: '10px solid transparent',
        borderTop: `22px solid #E33C3C`,
      }} />

      {/* Rotating wheel */}
      <svg
        viewBox={`0 0 ${SIZE} ${SIZE}`}
        width={SIZE} height={SIZE}
        style={{
          position: 'absolute', top: 80, left: '50%',
          marginLeft: -SIZE / 2, zIndex: 5,
          transform: `rotate(${rotation}deg)`,
          transformOrigin: '50% 50%',
          transition: spinning
            ? 'transform 4.2s cubic-bezier(0.17, 0.67, 0.32, 1.18)'
            : 'none',
          filter: `drop-shadow(0 6px 0 ${palette.ink}) drop-shadow(0 12px 12px rgba(0,0,0,0.4))`,
        }}
      >
        {/* Outer rim */}
        <circle cx={cx} cy={cy} r={rOuter} fill="#fff" stroke={palette.ink} strokeWidth={3} />
        {/* Rim dots */}
        {[...Array(N * 3)].map((_, i) => {
          const a = (i / (N * 3)) * 360;
          const p = kzPolar(cx, cy, rOuter - 5, a);
          return <circle key={i} cx={p.x} cy={p.y} r={2} fill={palette.ink} opacity={0.55} />;
        })}

        {/* Slices */}
        {quests.map((q, i) => {
          const start = i * slice;
          const end   = (i + 1) * slice;
          const p1 = kzPolar(cx, cy, rRim, start);
          const p2 = kzPolar(cx, cy, rRim, end);
          const large = slice > 180 ? 1 : 0;
          const path = `M ${cx} ${cy} L ${p1.x} ${p1.y} A ${rRim} ${rRim} 0 ${large} 1 ${p2.x} ${p2.y} Z`;
          const mid  = start + slice / 2;
          const labelPos = kzPolar(cx, cy, rRim - 26, mid);
          return (
            <g key={i}>
              <path d={path} fill={colorFor(i)} stroke={palette.ink} strokeWidth={2.5} strokeLinejoin="round" />
              <text
                x={labelPos.x} y={labelPos.y}
                transform={`rotate(${mid} ${labelPos.x} ${labelPos.y})`}
                fill="#fff" fontFamily="Lilita One, sans-serif"
                fontSize="13" letterSpacing="0.5"
                textAnchor="middle" dominantBaseline="central"
                stroke={palette.ink} strokeWidth="0.6" paintOrder="stroke"
              >
                {q.tag.toUpperCase()}
              </text>
            </g>
          );
        })}

        {/* Center hub */}
        <circle cx={cx} cy={cy} r={rHub} fill={palette.sun} stroke={palette.ink} strokeWidth={3} />
        <circle cx={cx} cy={cy} r={rHub - 6} fill="none" stroke={palette.ink} strokeWidth={1} opacity={0.3} />
        <text x={cx} y={cy} fill={palette.ink}
          fontFamily="Lilita One, sans-serif" fontSize="22"
          textAnchor="middle" dominantBaseline="central"
          letterSpacing="1"
        >
          DATE
        </text>
      </svg>

      {/* Blue floor mat — rectangular, perspective-tilted so it lies flat on the floor */}
      <div aria-hidden="true" style={{
        position: 'absolute', bottom: 4, left: '50%',
        transform: 'translateX(-50%)',
        width: 220, height: 110,
        perspective: '450px',
        zIndex: 7,
      }}>
        <div style={{
          width: '100%', height: '100%',
          transform: 'rotateX(58deg)',
          transformOrigin: '50% 100%',
          background: `linear-gradient(180deg, ${PLATFORM_HI} 0%, ${PLATFORM} 35%, ${PLATFORM_DEEP} 100%)`,
          border: `2.5px solid ${palette.ink}`,
          borderRadius: 8,
          boxShadow: `inset 0 4px 0 rgba(255,255,255,0.4), inset 0 -6px 0 rgba(0,0,0,0.2)`,
        }} />
      </div>

      {/* Red push-button — sits ON the mat, IN FRONT OF the wheel, with subtle 3D tilt */}
      <div style={{
        position: 'absolute', bottom: 14, left: '50%',
        transform: 'translateX(-50%)',
        zIndex: 8,
        perspective: '600px',
        width: 110, height: 110,
      }}>
        {/* Cast shadow on the mat */}
        <div aria-hidden="true" style={{
          position: 'absolute', bottom: 4, left: '50%',
          width: 96, height: 14,
          transform: 'translateX(-50%)',
          background: 'rgba(0,0,0,0.45)',
          borderRadius: '50%',
          filter: 'blur(3px)',
          zIndex: 1,
        }} />
        <button
          onMouseDown={() => setPressed(true)}
          onMouseUp={() => setPressed(false)}
          onMouseLeave={() => setPressed(false)}
          onTouchStart={() => setPressed(true)}
          onTouchEnd={() => setPressed(false)}
          onClick={spin}
          disabled={spinning}
          aria-label="Spin the wheel"
          style={{
            position: 'absolute', top: 8, left: '50%',
            width: 92, height: 92, borderRadius: 999,
            transform: `translateX(-50%) rotateX(22deg) translateY(${pressed && !spinning ? 6 : 0}px)`,
            transformOrigin: '50% 100%',
            background: `radial-gradient(circle at 32% 28%, #ff9595 0%, #E33C3C 50%, #8a1419 100%)`,
            border: `3px solid ${palette.ink}`,
            boxShadow: pressed && !spinning
              ? `0 2px 0 ${palette.ink}, inset 0 -4px 0 -1px rgba(0,0,0,0.4)`
              : `0 8px 0 ${palette.ink}, inset 0 -12px 0 -3px rgba(0,0,0,0.32), inset 0 10px 0 -3px rgba(255,255,255,0.45)`,
            color: '#fff',
            fontFamily: 'Lilita One, sans-serif',
            fontSize: 24, letterSpacing: 2,
            cursor: spinning ? 'wait' : 'pointer',
            textShadow: '0 2px 0 rgba(0,0,0,0.5), 0 0 4px rgba(0,0,0,0.3)',
            transition: 'transform .08s, box-shadow .08s',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            padding: 0,
            zIndex: 2,
          }}
        >
          SPIN
        </button>
      </div>
    </div>
  );
}

// ─── Main view ───────────────────────────────────────────────────────
function DateNightView({ palette, names, quests, questIdx, setQuestIdx, history }) {
  const [spinning, setSpinning] = React.useState(false);
  const currentQuest = quests[questIdx];
  const tagColor = palette[currentQuest.accent] || palette.sky;

  return (
    <div style={{ padding: '4px 18px 24px' }}>
      {/* Title */}
      <div style={{ textAlign: 'center', marginBottom: 10 }}>
        <div style={{ fontFamily: 'Caveat', fontSize: 26, color: '#fff', textShadow: `0 2px 0 ${palette.ink}` }}>Tonight, the wheel says...</div>
        <div className="kz-display" style={{ fontSize: 28, color: palette.ink, marginTop: 2, lineHeight: 1, textShadow: '0 2px 0 rgba(255,255,255,0.5)' }}>
          DATE WHEEL
        </div>
      </div>

      {/* Wheel */}
      <div style={{ position: 'relative', padding: '6px 0 14px' }}>
        <DateWheel
          quests={quests} palette={palette}
          spinning={spinning} setSpinning={setSpinning}
          onLand={(i) => setQuestIdx(i)}
        />
      </div>

      {/* Quest card */}
      <div className="kz-sticker" style={{
        '--ink': palette.ink,
        marginTop: 8, borderRadius: 22, padding: '14px 16px 16px',
        position: 'relative', overflow: 'hidden',
        transform: spinning ? 'scale(0.985)' : 'scale(1)',
        transition: 'transform .25s',
        opacity: spinning ? 0.55 : 1,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
          <div style={{ fontFamily: 'Caveat', fontSize: 18, color: tagColor, lineHeight: 1 }}>
            {spinning ? 'Spinning…' : 'Your quest'}
          </div>
          <Chip palette={palette} tone={currentQuest.accent}>★ {currentQuest.tag}</Chip>
        </div>
        <div className="kz-display" style={{
          fontSize: 22, color: palette.ink, lineHeight: 1.15, letterSpacing: 0,
        }}>
          {currentQuest.title}
        </div>
        <div style={{ marginTop: 6, fontSize: 13, color: palette.ink, opacity: 0.7, lineHeight: 1.4, fontWeight: 500 }}>
          {currentQuest.detail}
        </div>

        <div style={{ marginTop: 14, display: 'flex', gap: 8 }}>
          <ChunkyButton color="grass" palette={palette} icon="check" full
            onClick={() => alert('Accepted! Added to tonight\'s plan.')}>
            ACCEPT QUEST
          </ChunkyButton>
        </div>
      </div>

      {/* Recent quests */}
      <div style={{ marginTop: 22 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 10 }}>
          <div className="kz-display" style={{ fontSize: 16, color: palette.ink, letterSpacing: 0.4 }}>RECENT DATES</div>
          <button style={{
            background: 'transparent', border: 'none', color: palette.ink, opacity: 0.7,
            fontFamily: 'inherit', fontSize: 12, fontWeight: 700, cursor: 'pointer',
            textDecoration: 'underline',
          }}>See all</button>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {history.map((h, i) => (
            <div key={i} className="kz-sticker" style={{
              '--ink': palette.ink,
              borderRadius: 16, padding: '10px 14px',
              display: 'flex', alignItems: 'center', gap: 12,
              boxShadow: `0 4px 0 ${palette.ink}, 0 10px 18px -10px rgba(19,41,75,0.3)`,
            }}>
              <div style={{
                width: 36, height: 36, borderRadius: 12,
                background: `linear-gradient(180deg, ${palette[h.accent]}, ${kzShade(palette[h.accent], -15)})`,
                border: `2.5px solid ${palette.ink}`, color: '#fff',
                display: 'grid', placeItems: 'center', flexShrink: 0,
              }}>
                <Icon name={h.icon} size={17} />
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontWeight: 600, fontSize: 13, color: palette.ink, textOverflow: 'ellipsis', overflow: 'hidden', whiteSpace: 'nowrap' }}>{h.title}</div>
                <div style={{ fontSize: 11, color: palette.ink, opacity: 0.55, fontWeight: 600 }}>{h.when}</div>
              </div>
              {h.rating && (
                <div style={{ display: 'flex', gap: 1, color: palette.sun }}>
                  {[...Array(h.rating)].map((_, j) => (
                    <Icon key={j} name="star" size={13} fill="currentColor" strokeWidth={1.6} color={palette.ink} style={{ filter: `drop-shadow(0 0 0 ${palette.ink})` }} />
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

window.DateNightView = DateNightView;
