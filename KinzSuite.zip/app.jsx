// ─── App shell ───────────────────────────────────────────────────────

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "palette": "classic",
  "myName": "Jess",
  "partnerName": "Sam",
  "showSky": true
}/*EDITMODE-END*/;

function App() {
  const [tweaks, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const palette = window.KZ_DATA.PALETTES[tweaks.palette] || window.KZ_DATA.PALETTES.classic;
  const names = { me: tweaks.myName, partner: tweaks.partnerName };

  const [tab, setTab] = React.useState('today'); // today | gallery | date | chat
  const [partner, setPartner] = React.useState('me');
  const [selectedId, setSelectedId] = React.useState(window.KZ_DATA.MY_PETS[0].id);

  // Date night state
  const [questIdx, setQuestIdx] = React.useState(0);

  const mePet = window.KZ_DATA.MY_PETS[0];
  const partnerPet = window.KZ_DATA.PARTNER_PETS[0];
  const dateHistory = [
    { title: 'Bake heart-shaped sugar cookies', when: 'Last Friday',  icon: 'gift',  accent: 'blush', rating: 5 },
    { title: 'Sunset hike to the overlook',     when: 'May 4',         icon: 'pin',   accent: 'grass', rating: 4 },
    { title: 'Build a blanket fort & movie',    when: 'Apr 26',        icon: 'flame', accent: 'sun',   rating: 5 },
  ]; [
    { title: 'Bake heart-shaped sugar cookies', when: 'Last Friday',  icon: 'gift',  accent: 'blush', rating: 5 },
    { title: 'Sunset hike to the overlook',     when: 'May 4',         icon: 'pin',   accent: 'grass', rating: 4 },
    { title: 'Build a blanket fort & movie',    when: 'Apr 26',        icon: 'flame', accent: 'sun',   rating: 5 },
  ];

  const [tasks, setTasks] = React.useState(window.KZ_DATA.DAILY_TASKS_INIT);
  const [chat, setChat] = React.useState(window.KZ_DATA.CHAT_INIT);

  return (
    <div style={{
      width: '100%', height: '100%', position: 'relative', overflow: 'hidden',
      fontFamily: 'Fredoka, system-ui, sans-serif', color: palette.ink,
      display: 'flex', flexDirection: 'column',
    }}>
      {/* sky + clouds + grass backdrop */}
      {tweaks.showSky && <SkyBackground palette={palette} showClouds={true} showGrass={tab === 'gallery' || tab === 'date'} />}

      {/* Top brand bar — chunky sticker style */}
      <header style={{
        position: 'relative', zIndex: 3,
        padding: '54px 14px 6px',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8,
      }}>
        <div style={{
          display: 'inline-flex', alignItems: 'center', gap: 8,
          background: '#fff', padding: '5px 14px 5px 6px', borderRadius: 999,
          border: `2.5px solid ${palette.ink}`, boxShadow: `0 4px 0 ${palette.ink}`,
        }}>
          <div style={{ position: 'relative', width: 32, height: 32, flexShrink: 0 }}>
            <span style={{ position: 'absolute', inset: '2px 12px 2px 0', borderRadius: 999, background: palette.sky, border: `2px solid ${palette.ink}` }} />
            <span style={{ position: 'absolute', inset: '2px 0 2px 12px', borderRadius: 999, background: palette.blush, border: `2px solid ${palette.ink}` }} />
            <span style={{ position: 'absolute', top: 12, left: 14, width: 4, height: 4, borderRadius: 99, background: '#fff' }} />
          </div>
          <span className="kz-display" style={{ fontSize: 18, color: palette.ink }}>
            Kinz<span style={{ color: palette.blush }}>Suite</span>
          </span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <button aria-label="Notifications" className="kz-chunky" style={{
            width: 40, height: 40, padding: 0,
            background: `linear-gradient(180deg, ${palette.sun}, ${kzShade(palette.sun, -15)})`,
            color: palette.ink,
          }}>
            <Icon name="bell" size={18} strokeWidth={2.4} />
            <span style={{ position: 'absolute', top: -3, right: -3, width: 12, height: 12, borderRadius: 99, background: palette.blush, border: `2px solid ${palette.ink}` }} />
          </button>
          <button aria-label={`Chat with ${names.partner}`} onClick={() => setTab('chat')} className="kz-chunky" style={{
            width: 40, height: 40, padding: 0,
            background: `linear-gradient(180deg, ${palette.blush}, ${kzShade(palette.blush, -15)})`,
            color: '#fff',
          }}>
            <Icon name="bubble" size={18} strokeWidth={2.4} />
            <span style={{ position: 'absolute', top: -3, right: -3, width: 12, height: 12, borderRadius: 99, background: palette.sun, border: `2px solid ${palette.ink}` }} />
          </button>
        </div>
      </header>

      {/* Main view */}
      <main style={{ position: 'relative', zIndex: 2, flex: 1, minHeight: 0, overflowY: 'auto', display: 'flex', flexDirection: 'column' }} className="kz-hscroll">
        {tab === 'gallery' && (
          <GalleryView
            palette={palette} names={names}
            partner={partner} setPartner={setPartner}
            selectedId={selectedId} setSelectedId={setSelectedId}
          />
        )}
        {tab === 'date' && (
          <DateNightView
            palette={palette} names={names}
            quests={window.KZ_DATA.QUESTS}
            questIdx={questIdx} setQuestIdx={setQuestIdx}
            history={dateHistory}
          />
        )}
        {tab === 'today' && (
          <TodayView
            palette={palette} names={names}
            tasks={tasks} setTasks={setTasks}
          />
        )}
        {tab === 'chat' && (
          <ChatView
            palette={palette} names={names}
            chat={chat} setChat={setChat}
          />
        )}
      </main>

      {/* Bottom tab bar — chunky sticker pills */}
      <nav style={{
        position: 'relative', zIndex: 4,
        padding: '10px 10px calc(34px + 8px)',
        display: 'flex', justifyContent: 'space-around', gap: 4,
        background: 'rgba(255,255,255,0.85)',
        backdropFilter: 'blur(20px) saturate(180%)',
        WebkitBackdropFilter: 'blur(20px) saturate(180%)',
        borderTop: `2.5px solid ${palette.ink}`,
        boxShadow: '0 -10px 24px -10px rgba(19,41,75,0.18)',
      }}>
        {[
          { id: 'today',   label: 'Today',  icon: 'check',     tone: 'grass' },
          { id: 'gallery', label: 'Pets',   icon: 'paw',       tone: 'sky'   },
          { id: 'date',    label: 'Date',   icon: 'heartFill', tone: 'blush' },
        ].map(t => {
          const active = tab === t.id;
          const c = palette[t.tone];
          return (
            <button key={t.id} onClick={() => setTab(t.id)} style={{
              flex: 1, background: 'transparent', border: 'none', cursor: 'pointer',
              fontFamily: 'inherit', padding: 0, position: 'relative',
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3,
            }}>
              <div style={{
                width: 56, height: 38, borderRadius: 99,
                display: 'grid', placeItems: 'center',
                background: active ? `linear-gradient(180deg, ${c}, ${kzShade(c, -15)})` : '#fff',
                color: active ? '#fff' : palette.ink,
                border: `2.5px solid ${palette.ink}`,
                boxShadow: active
                  ? `0 3px 0 ${palette.ink}, inset 0 -4px 0 -1px rgba(0,0,0,0.18), inset 0 3px 0 -1px rgba(255,255,255,0.4)`
                  : `0 2px 0 ${palette.ink}`,
                transition: 'transform .12s',
                transform: active ? 'translateY(-2px)' : 'translateY(0)',
              }}>
                <Icon name={t.icon} size={20} strokeWidth={2.4} />
              </div>
              <span className="kz-display" style={{
                fontSize: 11, color: active ? c : palette.ink,
                letterSpacing: 0.6, opacity: active ? 1 : 0.7,
              }}>{t.label}</span>
            </button>
          );
        })}
      </nav>

      <TweaksPanel title="Tweaks">
        <TweakSection label="Palette">
          <TweakRadio label="Theme" value={tweaks.palette} onChange={v => setTweak('palette', v)}
            options={[
              { value: 'classic',  label: 'Sky'    },
              { value: 'twilight', label: 'Sunset' },
              { value: 'meadow',   label: 'Meadow' },
            ]} />
        </TweakSection>
        <TweakSection label="Names">
          <TweakText label="Me"      value={tweaks.myName}      onChange={v => setTweak('myName', v)} />
          <TweakText label="Partner" value={tweaks.partnerName} onChange={v => setTweak('partnerName', v)} />
        </TweakSection>
        <TweakSection label="Backdrop">
          <TweakToggle label="Sky &amp; clouds" value={tweaks.showSky} onChange={v => setTweak('showSky', v)} />
        </TweakSection>
        <TweakSection label="Navigate">
          <TweakRadio label="View" value={tab} onChange={setTab}
            options={[
              { value: 'today',   label: 'Today' },
              { value: 'gallery', label: 'Pets'  },
              { value: 'date',    label: 'Date'  },
              { value: 'chat',    label: 'Chat'  },
            ]} />
        </TweakSection>
      </TweaksPanel>
    </div>
  );
}

window.KinzApp = App;
