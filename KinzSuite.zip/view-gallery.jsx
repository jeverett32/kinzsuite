// ─── View 1: Pet Gallery ─────────────────────────────────────────────

function GalleryView({ palette, names, partner, setPartner, selectedId, setSelectedId }) {
  const pets = partner === 'me' ? window.KZ_DATA.MY_PETS : window.KZ_DATA.PARTNER_PETS;
  const scrollRef = React.useRef(null);
  const selected = pets.find(p => p.id === selectedId) || pets[0];

  React.useEffect(() => {
    if (!pets.find(p => p.id === selectedId)) setSelectedId(pets[0].id);
  }, [partner]); // eslint-disable-line

  return (
    <div style={{ padding: '0 0 24px', display: 'flex', flexDirection: 'column', flex: 1, minHeight: 0 }}>
      {/* Hero strip */}
      <div style={{ padding: '8px 18px 14px' }}>
        <div style={{ fontFamily: 'Caveat', fontSize: 44, color: '#fff', textShadow: `0 3px 0 ${palette.ink}, 0 0 12px rgba(0,0,0,0.15)`, lineHeight: 1 }}>Hey, {names.me}!</div>
      </div>

      {/* Owner toggle */}
      <div style={{ padding: '4px 18px 14px' }}>
        <PartnerToggle value={partner} onChange={setPartner} palette={palette} names={names} size="lg" />
      </div>

      {/* Horizontal scroll cards */}
      <div style={{ position: 'relative', flex: 1, display: 'flex', alignItems: 'center', minHeight: 0 }}>
        <div ref={scrollRef} style={{
          display: 'flex', gap: 18, padding: '6px 18px 22px',
          overflowX: 'auto', overflowY: 'visible',
          scrollSnapType: 'x mandatory',
          WebkitOverflowScrolling: 'touch',
          alignItems: 'center',
          width: '100%',
        }} className="kz-hscroll">
          {pets.map(p => (
            <div key={p.id} style={{ scrollSnapAlign: 'center' }}>
              <PolaroidCard pet={p} palette={palette}
                active={p.id === selected.id}
                onClick={() => setSelectedId(p.id)} />
            </div>
          ))}
          <button className="kz-sticker" style={{
            '--ink': palette.ink,
            width: 280, minHeight: 380, borderRadius: 32,
            background: `repeating-linear-gradient(135deg, #fff 0 14px, ${palette.sky}1F 14px 28px)`,
            display: 'flex', flexDirection: 'column', alignItems: 'center',
            justifyContent: 'center', gap: 14, cursor: 'pointer', color: palette.ink,
            fontFamily: 'inherit', flexShrink: 0,
          }}>
            <div style={{
              width: 84, height: 84, borderRadius: 99,
              background: `linear-gradient(180deg, ${palette.sun}, ${kzShade(palette.sun, -15)})`,
              border: `2.5px solid ${palette.ink}`, boxShadow: `0 4px 0 ${palette.ink}`,
              color: palette.ink, display: 'grid', placeItems: 'center',
            }}>
              <Icon name="plus" size={40} strokeWidth={3} />
            </div>
            <div className="kz-display" style={{ fontSize: 18, color: palette.ink, letterSpacing: 0.4 }}>ADOPT A FRIEND</div>
            <div style={{ fontSize: 13, fontWeight: 600, color: palette.ink, opacity: 0.6 }}>1,200 KinzCash</div>
          </button>
        </div>
      </div>

    </div>
  );
}

window.GalleryView = GalleryView;
