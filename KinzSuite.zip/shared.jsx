// Shared retro primitives: ChunkyButton, RainbowHeart, sky/cloud bg, sticker pet card, etc.

// ─── Pet portrait — chunky bordered circle ───────────────────────────
function PetPortrait({ art = 0, size = 180, rounded = 24, halo = true, border = true, palette }) {
  const pt = window.KZ_DATA.PET_TYPES[art % window.KZ_DATA.PET_TYPES.length];
  const fontSize = Math.round(size * 0.55);
  const ink = palette?.ink || '#13294B';
  return (
    <div style={{
      width: size, height: size, borderRadius: rounded, position: 'relative',
      overflow: 'hidden', flexShrink: 0,
      background: `radial-gradient(120% 100% at 30% 20%, ${pt.bColor} 0%, ${pt.aColor} 55%, ${pt.ear} 100%)`,
      boxShadow: halo ? `inset 0 0 0 4px rgba(255,255,255,0.55), inset 0 -8px 24px rgba(0,0,0,0.05)` : 'none',
      border: border ? `2.5px solid ${ink}` : 'none',
      boxSizing: 'border-box',
    }}>
      <div style={{ position: 'absolute', top: 10, right: 14, width: 6, height: 6, borderRadius: 99, background: 'rgba(255,255,255,0.8)' }} />
      <div style={{ position: 'absolute', top: 22, right: 26, width: 3, height: 3, borderRadius: 99, background: 'rgba(255,255,255,0.7)' }} />
      <div style={{ position: 'absolute', bottom: 16, left: 14, width: 4, height: 4, borderRadius: 99, background: 'rgba(255,255,255,0.6)' }} />
      <div style={{
        position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize, lineHeight: 1, filter: 'drop-shadow(0 6px 8px rgba(0,0,0,0.18))',
      }}>{pt.face}</div>
    </div>
  );
}

// ─── Polaroid card — sticker style ───────────────────────────────────
function PolaroidCard({ pet, palette, onClick, active }) {
  return (
    <button
      onClick={onClick}
      className={'kz-jiggle kz-sticker' + (active ? ' kz-jiggle-active' : '')}
      style={{
        '--ink': palette.ink,
        width: 280, padding: 14, paddingBottom: 18, borderRadius: 32,
        textAlign: 'left', cursor: 'pointer', fontFamily: 'inherit', flexShrink: 0,
        transform: active ? 'translateY(-4px) rotate(-1.2deg)' : 'rotate(-0.6deg)',
        transition: 'transform .25s cubic-bezier(.34,1.56,.64,1), box-shadow .25s',
      }}>
      <PetPortrait art={pet.art} size={252} rounded={22} palette={palette} />
      <div style={{ marginTop: 14 }}>
        <div className="kz-display" style={{ fontSize: 30, color: palette.ink, letterSpacing: -0.2, lineHeight: 1 }}>
          {pet.name}
        </div>
        <div style={{ marginTop: 8, display: 'flex', alignItems: 'center', gap: 6, color: palette.ink, fontSize: 14, fontWeight: 600, opacity: 0.7 }}>
          <Icon name="cake" size={14} strokeWidth={2.4} />
          <span>{pet.birthday}</span>
          <span style={{ width: 3, height: 3, background: 'currentColor', borderRadius: 99 }} />
          <span>{pet.species}</span>
        </div>
      </div>
    </button>
  );
}

// ─── Chip — chunky bordered ──────────────────────────────────────────
function Chip({ children, palette, tone = 'sky' }) {
  const c = palette[tone];
  return (
    <span style={{
      fontFamily: 'Lilita One', fontSize: 11, color: '#fff',
      background: c, padding: '4px 10px', borderRadius: 99,
      letterSpacing: 0.6, border: `2px solid ${palette.ink}`,
      boxShadow: `0 2px 0 ${palette.ink}`,
      textTransform: 'lowercase',
    }}>{children}</span>
  );
}

// ─── Chunky button ───────────────────────────────────────────────────
function ChunkyButton({ children, color = 'sun', palette, onClick, disabled, size = 'md', icon, style = {}, full = false, type }) {
  const c = palette[color] || color;
  const px = size === 'lg' ? '14px 24px' : size === 'sm' ? '7px 14px' : '10px 18px';
  const fontSize = size === 'lg' ? 17 : size === 'sm' ? 12 : 14;
  return (
    <button onClick={onClick} disabled={disabled} className="kz-chunky" style={{
      background: `linear-gradient(180deg, ${c} 0%, ${c} 60%, ${shade(c, -10)} 100%)`,
      color: contrastInk(c, palette.ink),
      padding: px, fontSize, width: full ? '100%' : 'auto',
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8,
      ...style,
    }}>
      {icon && <Icon name={icon} size={fontSize + 2} strokeWidth={2.4} />}
      {children}
    </button>
  );
}

function shade(hex, percent) {
  const n = parseInt(hex.replace('#', ''), 16);
  let r = (n >> 16) & 0xff, g = (n >> 8) & 0xff, b = n & 0xff;
  r = Math.max(0, Math.min(255, r + Math.round((255 - r) * percent / 100)));
  g = Math.max(0, Math.min(255, g + Math.round((255 - g) * percent / 100)));
  b = Math.max(0, Math.min(255, b + Math.round((255 - b) * percent / 100)));
  return '#' + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
}

function contrastInk(bg, ink) {
  // light on yellow keeps ink; for dark backgrounds switch to white.
  const n = parseInt(bg.replace('#', ''), 16);
  const r = (n >> 16) & 0xff, g = (n >> 8) & 0xff, b = n & 0xff;
  const lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  return lum > 0.6 ? ink : '#fff';
}

// ─── Rainbow heart status meter ──────────────────────────────────────
function RainbowHeart({ palette, stats }) {
  // stats = [{ label, value 0..1, color, icon }]
  const ink = palette.ink;
  return (
    <div style={{ position: 'relative', width: 140, height: 140, flexShrink: 0 }}>
      <svg viewBox="0 0 100 100" width="100%" height="100%" style={{ filter: `drop-shadow(0 4px 0 ${ink})` }}>
        <defs>
          <linearGradient id="kzRainbow" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%"  stopColor={palette.blush}/>
            <stop offset="33%" stopColor={palette.sun}/>
            <stop offset="66%" stopColor={palette.grass}/>
            <stop offset="100%" stopColor={palette.sky}/>
          </linearGradient>
        </defs>
        <path d="M50 88 C 14 60, 8 32, 28 22 C 38 17, 46 22, 50 32 C 54 22, 62 17, 72 22 C 92 32, 86 60, 50 88 Z"
              fill="url(#kzRainbow)" stroke={ink} strokeWidth="3" strokeLinejoin="round"/>
        {/* shine */}
        <ellipse cx="34" cy="32" rx="8" ry="5" fill="rgba(255,255,255,0.55)"/>
      </svg>
      {/* stat bars overlay */}
      <div style={{
        position: 'absolute', top: '50%', left: '50%',
        transform: 'translate(-50%, -50%)',
        display: 'flex', flexDirection: 'column', gap: 5, width: 64,
      }}>
        {stats.map((s, i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
            <div style={{
              width: 16, height: 16, borderRadius: 99, background: '#fff',
              border: `2px solid ${ink}`, display: 'grid', placeItems: 'center', flexShrink: 0,
              color: s.color, fontSize: 9,
            }}>
              <Icon name={s.icon} size={9} strokeWidth={2.6} />
            </div>
            <div style={{
              flex: 1, height: 10, background: 'rgba(255,255,255,0.65)',
              border: `2px solid ${ink}`, borderRadius: 99, overflow: 'hidden',
            }}>
              <div style={{ width: `${s.value * 100}%`, height: '100%', background: s.color, borderRadius: 99 }} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Cloud + grass background ────────────────────────────────────────
function SkyBackground({ palette, showClouds = true, showGrass = true }) {
  return (
    <div style={{ position: 'absolute', inset: 0, overflow: 'hidden', pointerEvents: 'none' }}>
      {/* Sky gradient */}
      <div style={{
        position: 'absolute', inset: 0,
        background: `linear-gradient(180deg, ${palette.sky} 0%, ${tint(palette.sky, 35)} 55%, ${tint(palette.sky, 60)} 92%)`,
      }} />
      {/* Sun glow */}
      <div style={{
        position: 'absolute', top: -60, right: -60, width: 200, height: 200,
        borderRadius: 999, background: `radial-gradient(circle, ${palette.sun}aa 0%, transparent 65%)`,
      }} />
      {/* Clouds */}
      {showClouds && <>
        <Cloud x="6%" y="18%" scale={1} delay={0} />
        <Cloud x="62%" y="9%" scale={0.7} delay={-6} />
        <Cloud x="78%" y="28%" scale={0.5} delay={-12} />
        <Cloud x="-4%" y="42%" scale={0.85} delay={-3} />
        <Cloud x="48%" y="48%" scale={0.6} delay={-9} />
      </>}
      {/* Grass hill */}
      {showGrass && (
        <div style={{
          position: 'absolute', bottom: -30, left: -40, right: -40, height: 130,
          background: `linear-gradient(180deg, ${palette.grass} 0%, ${shade(palette.grass, -25)} 100%)`,
          borderRadius: '50% 50% 0 0 / 60% 60% 0 0',
          borderTop: `3px solid ${palette.ink}`,
          opacity: 0.6,
        }} />
      )}
    </div>
  );
}

function Cloud({ x, y, scale = 1, delay = 0 }) {
  return (
    <div style={{
      position: 'absolute', left: x, top: y, transform: `scale(${scale})`,
      animation: `kz-drift 14s ease-in-out ${delay}s infinite alternate`,
      filter: 'drop-shadow(0 3px 0 rgba(19,41,75,0.18))',
    }}>
      <div style={{ position: 'relative', width: 110, height: 50 }}>
        <span style={{ position: 'absolute', left: 0,  top: 18, width: 38, height: 38, borderRadius: 999, background: '#fff' }} />
        <span style={{ position: 'absolute', left: 24, top: 4,  width: 46, height: 46, borderRadius: 999, background: '#fff' }} />
        <span style={{ position: 'absolute', left: 54, top: 12, width: 40, height: 40, borderRadius: 999, background: '#fff' }} />
        <span style={{ position: 'absolute', left: 72, top: 22, width: 32, height: 32, borderRadius: 999, background: '#fff' }} />
      </div>
    </div>
  );
}

function tint(hex, percent) { return shade(hex, percent); }

// ─── Partner toggle (Adopted/Medallions style tabs) ──────────────────
function PartnerToggle({ value, onChange, palette, names, size = 'md' }) {
  const isLg = size === 'lg';
  return (
    <div style={{ display: 'flex', gap: 8, width: '100%' }}>
      {[
        { id: 'me',      label: `${names.me}'s pets`,      tone: 'sky'  },
        { id: 'partner', label: `${names.partner}'s pets`, tone: 'blush'},
      ].map(o => {
        const active = value === o.id;
        const c = palette[o.tone];
        return (
          <button key={o.id} onClick={() => onChange(o.id)} className="kz-chunky" style={{
            background: active ? `linear-gradient(180deg, ${c}, ${shade(c, -15)})` : `linear-gradient(180deg, #fff, #F2F8FF)`,
            color: active ? '#fff' : palette.ink,
            fontSize: isLg ? 17 : 13,
            padding: isLg ? '14px 18px' : '8px 14px',
            flex: isLg ? 1 : '0 0 auto',
            transform: active ? 'translateY(0)' : 'translateY(2px)',
            opacity: active ? 1 : 0.85,
          }}>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: isLg ? 10 : 6 }}>
              <Icon name="paw" size={isLg ? 20 : 13} strokeWidth={2.4} />
              {o.label}
            </span>
          </button>
        );
      })}
    </div>
  );
}

window.PetPortrait = PetPortrait;
window.PolaroidCard = PolaroidCard;
window.Chip = Chip;
window.ChunkyButton = ChunkyButton;
window.SkyBackground = SkyBackground;
window.PawBackground = SkyBackground; // alias for back-compat
window.PartnerToggle = PartnerToggle;
window.RainbowHeart = RainbowHeart;
window.kzShade = shade;
