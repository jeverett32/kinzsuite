// ─── View 4: Chat ────────────────────────────────────────────────────

function ChatView({ palette, names, chat, setChat }) {
  const [draft, setDraft] = React.useState('');
  const [pendingPhoto, setPendingPhoto] = React.useState(false);
  const [showAttach, setShowAttach] = React.useState(false);
  const scrollerRef = React.useRef(null);

  React.useEffect(() => {
    if (scrollerRef.current) scrollerRef.current.scrollTop = scrollerRef.current.scrollHeight;
  }, [chat.length]);

  const send = () => {
    if (pendingPhoto) {
      const tint = Math.floor(Math.random() * window.KZ_DATA.PET_TYPES.length);
      setChat(c => [...c, { id: 'p' + Date.now(), who: 'me', name: 'You', kind: 'photo', tint, time: 'now' }]);
      setPendingPhoto(false);
      return;
    }
    if (!draft.trim()) return;
    setChat(c => [...c, { id: 'm' + Date.now(), who: 'me', name: 'You', text: draft.trim(), time: 'now' }]);
    setDraft('');
  };

  const quickReact = (msgId, emoji) => {
    setChat(c => c.map(m => m.id === msgId
      ? { ...m, reacts: [...(m.reacts || []), emoji] }
      : m));
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      {/* Header */}
      <div style={{ padding: '4px 14px 10px', display: 'flex', alignItems: 'center', gap: 10, flexShrink: 0 }}>
        <div style={{ display: 'flex', position: 'relative', flexShrink: 0 }}>
          <div style={{
            width: 48, height: 48, borderRadius: 99, overflow: 'hidden',
            border: `2.5px solid ${palette.ink}`, boxShadow: `0 3px 0 ${palette.ink}`,
          }}>
            <PetPortrait art={3} size={42} rounded={99} halo={false} border={false} />
          </div>
          <span style={{
            position: 'absolute', bottom: 0, right: 0, width: 14, height: 14,
            borderRadius: 99, background: palette.grass, border: `2px solid ${palette.ink}`,
          }} />
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div className="kz-display" style={{ fontSize: 20, color: palette.ink, letterSpacing: 0, lineHeight: 1, display: 'flex', alignItems: 'center', gap: 6 }}>
            {names.partner.toUpperCase()}
            <Icon name="heartFill" size={14} color={palette.blush} />
          </div>
          <div style={{ fontSize: 11, color: palette.grass, fontWeight: 700, marginTop: 2 }}>● online · in Kinzville</div>
        </div>
        <button aria-label="Pin" className="kz-chunky" style={{
          width: 36, height: 36, padding: 0,
          background: `linear-gradient(180deg, ${palette.blush}, ${kzShade(palette.blush, -15)})`,
          color: '#fff',
        }}>
          <Icon name="pin" size={16} strokeWidth={2.4} />
        </button>
      </div>

      {/* Pinned moment ribbon */}
      <div style={{ padding: '0 14px 8px', flexShrink: 0 }}>
        <div style={{
          display: 'flex', alignItems: 'center', gap: 10,
          background: `linear-gradient(95deg, ${palette.blush}26, ${palette.sun}26)`,
          padding: '8px 12px', borderRadius: 16,
          border: `2px solid ${palette.ink}`, boxShadow: `0 2px 0 ${palette.ink}`,
        }}>
          <div style={{
            width: 30, height: 30, borderRadius: 9,
            background: `linear-gradient(180deg, ${palette.blush}, ${kzShade(palette.blush, -15)})`,
            border: `2px solid ${palette.ink}`, color: '#fff',
            display: 'grid', placeItems: 'center', flexShrink: 0,
          }}>
            <Icon name="pin" size={14} />
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div className="kz-display" style={{ fontSize: 13, color: palette.ink, lineHeight: 1.1 }}>134 DAYS TOGETHER</div>
            <div style={{ fontSize: 11, color: palette.ink, opacity: 0.7, fontWeight: 600 }}>Anniversary trip thread →</div>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div ref={scrollerRef} style={{
        flex: 1, minHeight: 0, overflowY: 'auto',
        padding: '6px 14px 8px',
        display: 'flex', flexDirection: 'column', gap: 6,
      }} className="kz-hscroll">
        <div className="kz-display" style={{
          alignSelf: 'center', fontSize: 10, color: palette.ink,
          background: '#fff', padding: '4px 12px', borderRadius: 99,
          letterSpacing: 0.8, margin: '4px 0',
          border: `2px solid ${palette.ink}`, boxShadow: `0 2px 0 ${palette.ink}`,
        }}>TODAY</div>
        {chat.map((m, i) => (
          <ChatBubble key={m.id} msg={m} palette={palette} prev={chat[i - 1]} names={names}
            onReact={(emoji) => quickReact(m.id, emoji)} />
        ))}
        {pendingPhoto && (
          <div style={{ alignSelf: 'flex-end', display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 4, maxWidth: '80%' }}>
            <div style={{
              width: 160, height: 116, borderRadius: 16,
              background: `repeating-linear-gradient(45deg, ${palette.sky}33 0 8px, ${palette.sky}1A 8px 16px)`,
              border: `2.5px dashed ${palette.ink}`, display: 'grid', placeItems: 'center',
              color: palette.ink, fontFamily: 'Lilita One', fontSize: 12, letterSpacing: 0.5,
            }}>PHOTO ATTACHED</div>
            <span style={{ fontSize: 10, color: palette.ink, opacity: 0.6, fontWeight: 600 }}>tap send →</span>
          </div>
        )}
      </div>

      {/* Quick-reaction strip */}
      <div style={{ padding: '0 14px 6px', display: 'flex', gap: 6, flexShrink: 0 }}>
        {['❤️','😂','🥹','🐾','🔥'].map(e => (
          <button key={e} onClick={() => {
            const last = chat[chat.length - 1];
            if (last) quickReact(last.id, e);
          }} style={{
            border: `2px solid ${palette.ink}`, cursor: 'pointer', background: '#fff',
            padding: '4px 10px', borderRadius: 99, fontSize: 14,
            boxShadow: `0 2px 0 ${palette.ink}`, fontFamily: 'inherit',
          }}>{e}</button>
        ))}
      </div>

      {/* Composer */}
      <div style={{ padding: '6px 14px 12px', flexShrink: 0 }}>
        {showAttach && (
          <div className="kz-sticker" style={{
            '--ink': palette.ink, borderRadius: 18, padding: 12, marginBottom: 8,
            display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8,
          }}>
            {[
              { icon: 'camera', label: 'PHOTO', c: palette.sky,   onClick: () => { setPendingPhoto(true); setShowAttach(false); } },
              { icon: 'gift',   label: 'GIFT',  c: palette.blush, onClick: () => setShowAttach(false) },
              { icon: 'paw',    label: 'PET',   c: palette.grass, onClick: () => setShowAttach(false) },
              { icon: 'pin',    label: 'PLACE', c: palette.sun,   onClick: () => setShowAttach(false) },
            ].map((a, i) => (
              <button key={i} onClick={a.onClick} style={{
                background: 'transparent', border: 'none', cursor: 'pointer', fontFamily: 'inherit',
                display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 5, padding: 4,
              }}>
                <div style={{
                  width: 44, height: 44, borderRadius: 14,
                  background: `linear-gradient(180deg, ${a.c}, ${kzShade(a.c, -15)})`,
                  border: `2.5px solid ${palette.ink}`, boxShadow: `0 3px 0 ${palette.ink}`,
                  color: '#fff', display: 'grid', placeItems: 'center',
                }}>
                  <Icon name={a.icon} size={20} strokeWidth={2.4} />
                </div>
                <span className="kz-display" style={{ fontSize: 10, color: palette.ink, letterSpacing: 0.4 }}>{a.label}</span>
              </button>
            ))}
          </div>
        )}
        <div style={{
          background: '#fff', borderRadius: 99, padding: 4,
          display: 'flex', alignItems: 'center', gap: 4,
          border: `2.5px solid ${palette.ink}`, boxShadow: `0 3px 0 ${palette.ink}`,
        }}>
          <button onClick={() => setShowAttach(s => !s)} aria-label="Attach" style={{
            width: 38, height: 38, borderRadius: 99, border: `2px solid ${palette.ink}`, cursor: 'pointer',
            background: showAttach
              ? `linear-gradient(180deg, ${palette.sky}, ${kzShade(palette.sky, -15)})`
              : '#fff',
            color: showAttach ? '#fff' : palette.ink,
            display: 'grid', placeItems: 'center', flexShrink: 0,
            transform: showAttach ? 'rotate(45deg)' : 'rotate(0)',
            transition: 'transform .2s, background .15s',
          }}>
            <Icon name="plus" size={20} strokeWidth={2.6} />
          </button>
          <button onClick={() => { setPendingPhoto(p => !p); setShowAttach(false); }} aria-label="Camera" style={{
            width: 38, height: 38, borderRadius: 99, border: 'none', cursor: 'pointer',
            background: pendingPhoto ? palette.sky : 'transparent',
            color: pendingPhoto ? '#fff' : palette.ink,
            display: 'grid', placeItems: 'center', flexShrink: 0,
          }}>
            <Icon name="camera" size={18} strokeWidth={2.2} />
          </button>
          <input
            value={draft}
            onChange={e => setDraft(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter') send(); }}
            placeholder={`Message ${names.partner}…`}
            style={{
              flex: 1, minWidth: 0, border: 'none', outline: 'none', background: 'transparent',
              padding: '8px 6px', fontFamily: 'inherit', fontSize: 14, fontWeight: 500, color: palette.ink,
            }}
          />
          <button onClick={send} aria-label="Send" disabled={!draft.trim() && !pendingPhoto} style={{
            width: 42, height: 42, borderRadius: 99, cursor: 'pointer',
            background: (draft.trim() || pendingPhoto)
              ? `linear-gradient(180deg, ${palette.blush}, ${kzShade(palette.blush, -15)})`
              : '#fff',
            color: (draft.trim() || pendingPhoto) ? '#fff' : palette.ink,
            border: `2px solid ${palette.ink}`,
            display: 'grid', placeItems: 'center', flexShrink: 0,
            boxShadow: (draft.trim() || pendingPhoto) ? `0 3px 0 ${palette.ink}` : 'none',
            transition: 'background .15s',
          }}>
            <Icon name="send" size={16} strokeWidth={2.6} />
          </button>
        </div>
      </div>
    </div>
  );
}

function ChatBubble({ msg, palette, prev, names, onReact }) {
  const isMe = msg.who === 'me';
  const consecutive = prev && prev.who === msg.who;
  const bubbleBg = isMe
    ? `linear-gradient(180deg, ${palette.sky}, ${window.kzShade(palette.sky, -10)})`
    : '#fff';
  const text = isMe ? '#fff' : palette.ink;
  const radius = isMe
    ? `20px ${consecutive ? 8 : 20}px 8px 20px`
    : `${consecutive ? 8 : 20}px 20px 20px 8px`;
  return (
    <div style={{
      display: 'flex', flexDirection: 'column', alignItems: isMe ? 'flex-end' : 'flex-start',
      maxWidth: '78%', gap: 2, alignSelf: isMe ? 'flex-end' : 'flex-start',
    }}>
      {!consecutive && (
        <div className="kz-display" style={{
          fontSize: 10, color: palette.ink, opacity: 0.6, padding: '0 10px', letterSpacing: 0.4,
        }}>
          {msg.name.toUpperCase()} · {msg.time}
        </div>
      )}
      {msg.kind === 'photo' ? (
        <div style={{
          width: 168, height: 122, borderRadius: 18,
          border: `3px solid ${palette.ink}`,
          background: `linear-gradient(135deg, ${window.KZ_DATA.PET_TYPES[msg.tint % 8].aColor}, ${window.KZ_DATA.PET_TYPES[msg.tint % 8].bColor})`,
          boxShadow: `0 3px 0 ${palette.ink}`,
          display: 'grid', placeItems: 'center',
          fontSize: 56, lineHeight: 1, filter: 'drop-shadow(0 4px 6px rgba(0,0,0,0.12))',
        }}>
          {window.KZ_DATA.PET_TYPES[msg.tint % 8].face}
        </div>
      ) : (
        <div style={{
          background: bubbleBg, color: text, padding: '8px 13px', borderRadius: radius,
          fontSize: 14, lineHeight: 1.35, fontWeight: 600,
          border: `2px solid ${palette.ink}`,
          boxShadow: `0 2px 0 ${palette.ink}`,
          wordBreak: 'break-word',
        }}>{msg.text}</div>
      )}
      {msg.reacts?.length > 0 && (
        <div style={{
          display: 'flex', gap: 2, padding: '2px 7px', borderRadius: 99,
          background: '#fff', border: `2px solid ${palette.ink}`, boxShadow: `0 2px 0 ${palette.ink}`,
          marginTop: -4, marginLeft: isMe ? 0 : 8, marginRight: isMe ? 8 : 0, fontSize: 12,
        }}>
          {msg.reacts.map((r, i) => <span key={i}>{r}</span>)}
        </div>
      )}
    </div>
  );
}

window.ChatView = ChatView;
