// Sample data for the KinzSuite prototype.
// All creatures and names are original — no branded characters.

const PALETTES = {
  classic:  { sky: '#3FB8E8', sun: '#FFC93C', grass: '#7BC043', blush: '#FF6FA3', purple: '#A05CFF', cream: '#EAF6FF', ink: '#13294B', navy: '#13294B' },
  twilight: { sky: '#7A6CF0', sun: '#FFB347', grass: '#5BCEAE', blush: '#FF5C8A', purple: '#C062E0', cream: '#F1ECFF', ink: '#1B0F45', navy: '#1B0F45' },
  meadow:   { sky: '#4CB7A0', sun: '#F2C94C', grass: '#8FCB5F', blush: '#EC7F8E', purple: '#9C7DE0', cream: '#EFFAF1', ink: '#13332A', navy: '#13332A' },
};

const PET_TYPES = [
  { type: 'Cloud Pup',    aColor: '#A6DFFF', bColor: '#FFFFFF', ear: '#9CCFEF', face: '🐶' },
  { type: 'Sunny Cat',    aColor: '#FFE6A6', bColor: '#FFF3CC', ear: '#F5C97D', face: '🐱' },
  { type: 'Mossy Bear',   aColor: '#C7E89A', bColor: '#E8F3CD', ear: '#9CC472', face: '🐻' },
  { type: 'Bubble Bunny', aColor: '#FFC9DD', bColor: '#FFE3EF', ear: '#F39FBE', face: '🐰' },
  { type: 'Pond Frog',    aColor: '#A4E5C5', bColor: '#D3F2DF', ear: '#7DD0AA', face: '🐸' },
  { type: 'Sock Fox',     aColor: '#FFB892', bColor: '#FFD9C2', ear: '#F09368', face: '🦊' },
  { type: 'Dusty Owl',    aColor: '#D7C7FF', bColor: '#ECE2FF', ear: '#B9A2F0', face: '🦉' },
  { type: 'Puddle Duck',  aColor: '#FFE291', bColor: '#FFF1BE', ear: '#F2C859', face: '🦆' },
];

const MY_PETS = [
  { id: 1, name: 'Marshmellow', species: 'Cloud Pup',    birthday: 'Apr 02, 2023', adopted: '2 yrs',  level: 14, mood: 'cozy',   art: 0 },
  { id: 2, name: 'Pickle',      species: 'Pond Frog',    birthday: 'Sep 14, 2024', adopted: '8 mos',  level: 7,  mood: 'silly',  art: 4 },
  { id: 3, name: 'Biscuit',     species: 'Sunny Cat',    birthday: 'Jan 21, 2022', adopted: '3 yrs',  level: 22, mood: 'sleepy', art: 1 },
  { id: 4, name: 'Acorn',       species: 'Mossy Bear',   birthday: 'Oct 30, 2023', adopted: '1.5 yr', level: 11, mood: 'hungry', art: 2 },
];

const PARTNER_PETS = [
  { id: 5, name: 'Noodle',     species: 'Bubble Bunny', birthday: 'Jul 11, 2023', adopted: '2 yrs', level: 16, mood: 'flirty',  art: 3 },
  { id: 6, name: 'Cinnamon',   species: 'Sock Fox',     birthday: 'Feb 14, 2024', adopted: '1 yr',  level: 9,  mood: 'sneaky',  art: 5 },
  { id: 7, name: 'Sir Hoots',  species: 'Dusty Owl',    birthday: 'Dec 06, 2022', adopted: '3 yrs', level: 19, mood: 'wise',    art: 6 },
  { id: 8, name: 'Quackers',   species: 'Puddle Duck',  birthday: 'May 30, 2024', adopted: '11 mos',level: 6,  mood: 'splashy', art: 7 },
];

const QUESTS = [
  { tag: 'Arcade',    title: 'Beat your high score in Cash Cow Returns', detail: 'Loser owes the winner a backrub.', accent: 'sun'   },
  { tag: 'Garden',    title: 'Plant a brand-new flowerbed together',     detail: 'Bonus: pick a color you’ve never used.', accent: 'grass' },
  { tag: 'Cooking',   title: 'Bake heart-shaped sugar cookies',           detail: 'Frost each other’s pet on top.', accent: 'blush' },
  { tag: 'Adventure', title: 'Hike to a spot you’ve never visited',       detail: 'Take a polaroid for the gallery.', accent: 'sky'   },
  { tag: 'Cozy',      title: 'Build a blanket fort and pick a movie',     detail: 'Loser of rock-paper-scissors picks snacks.', accent: 'blush' },
  { tag: 'Music',     title: 'Slow dance to one full song',               detail: 'No phones. Eye contact required.', accent: 'sun'   },
  { tag: 'Quest',     title: 'Trade three pet outfits with each other',   detail: 'Style your partner’s pet for tomorrow.', accent: 'grass' },
  { tag: 'Travel',    title: 'Plan a 24-hr surprise trip on paper',       detail: 'Reveal at breakfast on Saturday.', accent: 'sky'   },
];

const DAILY_TASKS_INIT = [
  { id: 't1', label: 'Wheel of Wow',     reward: '+250 ★', done: true,  who: 'both' },
  { id: 't2', label: 'Gem Hunt',         reward: '+3 gems', done: true,  who: 'me'   },
  { id: 't3', label: 'Feed all pets',    reward: '+1 ❤︎',  done: false, who: 'both' },
  { id: 't4', label: 'Water the garden', reward: '+50 ★', done: false, who: 'partner' },
  { id: 't5', label: 'Daily Kinz Quiz',  reward: '+1 trophy', done: false, who: 'me' },
  { id: 't6', label: 'Tuck pets in',     reward: '+1 ❤︎',  done: false, who: 'both' },
];

const CHAT_INIT = [
  { id: 'c1', who: 'partner', name: 'Sam', text: 'Noodle put on the hat you gave her 🥹', time: '8:14a', reacts: ['❤️'] },
  { id: 'c2', who: 'partner', name: 'Sam', kind: 'photo', tint: 3,                            time: '8:14a' },
  { id: 'c3', who: 'me',      name: 'You', text: 'STOP it’s perfect on her',                  time: '8:16a', reacts: ['😭','🌸'] },
  { id: 'c4', who: 'me',      name: 'You', text: 'Biscuit refuses to leave the loaf',         time: '8:42a' },
  { id: 'c5', who: 'me',      name: 'You', kind: 'photo', tint: 1,                            time: '8:42a' },
  { id: 'c6', who: 'partner', name: 'Sam', text: 'Loaf supremacy 🍞',                          time: '8:45a', reacts: ['🤣'] },
];

window.KZ_DATA = { PALETTES, PET_TYPES, MY_PETS, PARTNER_PETS, QUESTS, DAILY_TASKS_INIT, CHAT_INIT };
